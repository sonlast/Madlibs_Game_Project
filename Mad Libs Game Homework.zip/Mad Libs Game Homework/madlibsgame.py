# print("I have a big 1. _____ and I like to 2. _____ every day. You can see me as a 3. _____ "
#     "person with 4. ______ personalities. Now I'm 5. _____ in golf, and I'm always 6. _____ in everything I
#     7. _____. ")

first = input("Enter your noun: ")
second = input("Enter a verb: ")
third = input("Enter an adjective: ")
fourth = input("Enter an adjective: ")
fifth = input("Enter an adjective: ")
sixth = input("Enter a sport: ")
seventh = input("Enter an adjective: ")
eight = input("Enter an verb: ")

print("")
print("I have a big " + first + " and I like to " + second + " every day. You can see me as a/an " + third +
      " person with " + fourth + " personalities. Now I'm " + fifth + " in " + sixth + " and I'm always " + seventh +
      " in everything I/I'm " + eight + ". ")
